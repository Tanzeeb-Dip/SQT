if exists("1524062703500.png"):
    doubleClick("1524062755660.png")
    click("1524062786659.png")
    exists("1524062832816.png")
    print "Test case 1 is passed"
else:
    print"Test case 1 is failed"



if exists("1524063269904.png"):
    click("1524063278261.png")
    exists("1524063291596.png")
    print "Test case 2 is passed"
else:
    print "Test case 2 is failed"

if exists("1524064010314.png"):
    click("1524064019750.png")
    exists("1524064037856.png")
    print "Test case 3 is passed"
else:
    print "Test case 3 is failed"


if exists("1524064108203.png"):
    click("1524064117671.png")
    exists("1524064131134.png")
    print "Test case 4 is passed"

else:
    print "Test case 4 is failed"

if exists("1524064202115.png"):
   click("1524064221749.png")
   exists("1524064296183.png")
   
   print "Test case 5 is passed"
else:
    print "Test case 5 is failed"



if exists("1524064343376.png"):
    click("1524064350776.png")
    exists("1524064367528.png")
    print "Test case 6 is passed"

else:
    print "Test case 6 is failed"


if exists("1524064439238.png"):
    click("1524064458876.png")
    exists("1524064478409.png")
    print "Test case 7 is passed"
else:
    print "Test case 7 is failed"


if exists("1524064736188.png"):
    click("1524064744126.png")
    exists("1524064756756.png")
    print "Test case 8 is passed"
else:
    print "Test case 8 is failed"

if exists("1524064835337.png"):
    click("1524064844825.png")
    type("Project")

    doubleClick("1524064894285.png")
    click("1524064930900.png")
    click("1524064942829.png")
    click("1524064965820.png")
    exists("1524065015254.png")
    print "Test case 9 is passed"

else:
     print "Test case 9 is failed"



if exists("1524065113685.png"):
    doubleClick("1524065123632.png")
    click("1524065177154.png")
    click("1524065185596.png")
    exists("1524065207357.png")
    print "Test case 10 is passed"
else:
    print "Test case 10 is failed"



if exists("1524065328913.png"):
    doubleClick("1524065341485.png")
    click("1524065359110.png")
    click("1524065367365.png")
    print "Test case 11 is passed"

else:
     print "Test case 11 is failed"


if exists("1524065543156.png"):
    doubleClick("1524065553116.png")
    doubleClick("1524065575030.png")
    type("75")
    click("1524065603356.png")
    print "Test case 12 is passed"
else :
    print "Test case 12 is failed"



if exists("1524066763430.png"):

    doubleClick("1524067102189.png")
    
    
    
    click("1524066773247.png")
    click("1524066805348.png")
    exists("1524066827208.png")
    print "Test case 16 is passed"


else :
    print "Test case 16 is failed"


if exists("1524067267641.png"):
    doubleClick("1524067282443.png")
    click("1524067295172.png")
    click("1524067307847.png")
    click("1524067313960.png")
    print "Test case 17 is passed"
else:
    print "Test case 17 is failed"

if exists("1524067433908.png"):
    doubleClick("1524067444132.png")
    click("1524067459228.png")
    click("1524067465763.png")
    print "Test case 18 is passed"

else :
    print "Test case 18 is failed"

  

if exists("1524068180940.png"):
    doubleClick("1524068205687.png")
    type('c',Key.CTRL)

    click("1524068568366.png")
    type ('v',Key.CTRL)

    print "Test case 23 is passed"

else:
    print "Test case 23 is failed"
    
    

if exists("1524069434661.png"):
    click("1524069460837.png")
    click("1524069477276.png")
    click("1.PNG")
       
    click("1524069534083.png")
    exists("1524069550113.png")
    print "Test case 26 is passed"

else:
    print "Test case 26 is failed"
    

if exists("1524070699291.png"):
    click("1524070707709.png")
    click("1524072161006.png")
    exists("1524072187011.png")
    
   
    
    print "Test case 41 is passed"
else:
    print "Test case 41 is failed"



    
   

    
    